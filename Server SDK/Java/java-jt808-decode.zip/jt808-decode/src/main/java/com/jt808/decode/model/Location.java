package com.jt808.decode.model;

import com.jt808.decode.constant.AlarmTypeEnum;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 定位数据
 * @author HyoJung
 * @date 20230303
 */
@Data
public class Location {
    private String terminalNum;
    private String hexMsgId;
    private int msgFlowId;
    private Integer locationType=-1;
    private Integer acc = -1;
    private Double lat;
    private Double lon;
    private Integer altitude;
    private Double speed;
    private Integer direction;
    private Double mileage= 0.0;
    private List<String> lbsCells;
    private String gnssTime;
    private String recvTime;
    private Integer battery = 0;
    private Double voltage = 0.0;
    private Integer gsmValue = 0;
    private Integer gnssValue = 0;
    private List<AlarmTypeEnum> alarmTypeList = new ArrayList<>();
    private Map<String,Integer> statusMap;
    private Map<String,Object> expandMap;
    private String replyMsg;
}
