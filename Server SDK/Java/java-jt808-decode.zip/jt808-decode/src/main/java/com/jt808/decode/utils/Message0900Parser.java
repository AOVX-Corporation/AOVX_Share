package com.jt808.decode.utils;

import com.jt808.decode.model.Jt808Message;
import com.jt808.decode.model.PassThroughData;
import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;

/**
 * Data uplink transparent transmission
 * @author HyoJung
 * @date 20230303
 */
public class Message0900Parser {

    /**
     * Data uplink transparent transmission
     * @param msg
     * @param msgBodyBuf
     * @return
     */
    public static PassThroughData parser(Jt808Message msg, ByteBuf msgBodyBuf){
        //Transparent message type
        int msgType = msgBodyBuf.readUnsignedByte();
        //Transparent message content
        int msgContentLen = msgBodyBuf.readableBytes();
        byte[] msgContentArr = null;
        if (msgContentLen > 0) {
            msgContentArr = new byte[msgContentLen];
            msgBodyBuf.readBytes(msgContentArr);
        }
        PassThroughData passThroughData=new PassThroughData();
        passThroughData.setTerminalNum(msg.getPhoneNumber());
        passThroughData.setHexMsgId(NumberUtil.formatMessageId(msg.getMsgId()));
        passThroughData.setMsgFlowId(msg.getMsgFlowId());
        passThroughData.setMsgType(msgType);
        passThroughData.setMsgContent(ByteBufUtil.hexDump(msgContentArr));
        return passThroughData;
    }
}
