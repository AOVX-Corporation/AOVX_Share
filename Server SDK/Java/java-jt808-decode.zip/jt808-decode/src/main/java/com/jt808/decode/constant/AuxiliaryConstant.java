package com.jt808.decode.constant;

/**
 * Auxiliary information
 * @author HyoJung
 * @date 2022-09-27
 */
public class AuxiliaryConstant {
    public AuxiliaryConstant(){
    }
    public static final String POSITION_AGE="position_age";
    public static final String ACC_DURATION="acc_duration";
    public static final String HDOP="hdop";
    public static final String GNSS_TIME="gnss_time";
    public static final String STATE_REGISTER_INFO="state_register_info";
}
