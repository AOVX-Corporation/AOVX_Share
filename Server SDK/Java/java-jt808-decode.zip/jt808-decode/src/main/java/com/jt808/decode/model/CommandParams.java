package com.jt808.decode.model;

import lombok.Data;

import java.util.LinkedHashMap;

/**
 * 指令编码实体类
 * @author Mr.Li
 * @date 2023-11-09
 */
@Data
public class CommandParams {
    private String terminalNum;
    private Integer msgId;
    private int msgFlowId;
    private LinkedHashMap<Integer,Object> params;
    private LinkedHashMap<String,Object> strKeyParams;
}
