package com.jt808.decode.constant;

/**
 * <p>Description: JT808 constant</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2018/2/3
 */
public class Jt808Constant {

    private Jt808Constant() {
    }
    /**
     * Message header and footer
     */
    public static final byte MSG_HEAD_TAIL_FLAG = 0x7E;

    /**
     * Basic length excluding message body
     */
    public static final int MSG_BASE_LENGTH = 15;

    /**
     * JT808-2019 Basic length excluding message body
     */
    public static final int JT2019_MSG_BASE_LENGTH = 20;

    /**
     * Maximum message length
     */
    public static final int MSG_MAX_LENGTH = 102400;
}

