package com.jt808.decode.model;

import lombok.Data;

import java.util.Map;

/**
 * Terminal parameter query response
 * @author HyoJung
 * @date 2022/9/21
 */
@Data
public class DeviceParam {
    private String terminalNum;
    private String hexMsgId;
    private int msgFlowId;
    /**
     * Response serial number
     */
    private int replyMsgFlowId;
    /**
     * Number of parameters
     */
    private int itemCount;
    /**
     * parameter map
     */
    private Map<String, Object> itemMap;
}
