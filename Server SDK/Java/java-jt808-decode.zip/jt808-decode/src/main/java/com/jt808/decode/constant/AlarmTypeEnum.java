package com.jt808.decode.constant;

import lombok.Getter;

/**
 * <p>Description: Terminal Alarm enum</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2022-9-20
 */
public enum AlarmTypeEnum implements BaseEnum<String> {

    ALARM_0("Emergency", "0"),
    ALARM_1("Speed Alarm", "1"),
    ALARM_2("Fatigue driving", "2"),
    ALARM_3("Danger warning", "3"),
    ALARM_4("GNSS module failure", "4"),
    ALARM_5("GNSS antenna disconnected", "5"),
    ALARM_6("GNSS antenna short circuit", "6"),
    ALARM_7("Undervoltage of main power supply", "7"),
    ALARM_8("Power failure of main power supply", "8"),
    ALARM_9("Display failure", "9"),
    ALARM_10("TTS module failure", "10"),
    ALARM_11("Camera fault", "11"),
    ALARM_12("Road transport certificate IC card module failure", "12"),
    ALARM_13("Overspeed warning", "13"),
    ALARM_14("Fatigue driving warning", "14"),
    ALARM_15("Removal alarm", "15"),
    ALARM_16("Vibration alarm", "16"),
    ALARM_18("Accumulated driving overtime of the day", "18"),
    ALARM_19("Overtime parking", "19"),
    ALARM_20("Access area", "20"),
    ALARM_21("Access route", "21"),
    ALARM_22("Insufficient/too long driving time", "22"),
    ALARM_23("Route deviation alarm", "23"),
    ALARM_24("Vehicle VSS failure", "24"),
    ALARM_25("Fuel quantity is abnormal", "25"),
    ALARM_26("Vehicle stolen", "26"),
    ALARM_27("Illegal ignition of vehicle", "27"),
    ALARM_28("Illegal vehicle displacement", "28"),
    ALARM_29("Collision warning", "29"),
    ALARM_30("Rollover warning", "30"),
    ALARM_31("Illegal door opening alarm", "31"),

    CUSTOM_ALARM_1("SOS", "200"),
    CUSTOM_ALARM_2("Temp&humidity alarm", "201"),
    CUSTOM_ALARM_4("Light alarm", "203"),
    CUSTOM_ALARM_5("Water immersion alarm", "204"),
    CUSTOM_ALARM_6("Low battery", "205"),
    CUSTOM_ALARM_7("One button alarm", "206"),
    CUSTOM_ALARM_8("Release the one button alarm", "207"),
    CUSTOM_ALARM_9("Rapid acceleration", "208"),
    CUSTOM_ALARM_10("Sharp deceleration", "209"),
    CUSTOM_ALARM_11("Sharp turn", "210"),
    CUSTOM_ALARM_12("Device abnormal", "211"),
    CUSTOM_ALARM_13("Pressure alarm", "212"),
    CUSTOM_ALARM_14("Jamming alarm", "213"),
    CUSTOM_ALARM_15("NoJamming alarm", "214"),
    CUSTOM_ALARM_16("Idling alarm", "215"),
    CUSTOM_ALARM_17("NoIdling alarm", "216"),
    CUSTOM_ALARM_18("Low speed", "217"),
    CUSTOM_ALARM_19("Abnormal angle", "218"),
    CUSTOM_ALARM_20("Flat fall alarm", "219"),
    CUSTOM_ALARM_21("Corner drop alarm", "220"),
    CUSTOM_ALARM_22("Overturn alarm", "221");

    @Getter
    private String desc;

    private String value;

    AlarmTypeEnum(String desc, String value) {
        this.desc = desc;
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    public static AlarmTypeEnum fromValue(Integer value) {
        String valueStr = String.valueOf(value);
        for (AlarmTypeEnum alarmTypeEnum : values()) {
            if (alarmTypeEnum.getValue().equals(valueStr)) {
                return alarmTypeEnum;
            }
        }
        return null;
    }
}
