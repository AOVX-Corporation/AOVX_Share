package com.jt808.decode.model;

import lombok.Data;

/**
 * <p>Description: Transparent transmission of data</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2018/9/15
 */
@Data
public class PassThroughData {
    private String terminalNum;
    private String hexMsgId;
    private int msgFlowId;
    /**
     * Transparent message type
     */
    private int msgType;

    /**
     * Transparent message content
     */
    private String msgContent;
}
