package com.jt808.decode.model;

import lombok.Data;

/**
 * 心跳包实体类
 * @author HyoJung
 * @date 20230303
 */
@Data
public class Heartbeat {
    private String terminalNum;
    private String hexMsgId;
    private int msgFlowId;
    private String replyMsg;
}
