package com.jt808.decode.constant;

/**
 * aovx mater information
 * @author lenny
 * @date 2022-09-26
 */
public class MeterConstant {
    private MeterConstant() {
    }

    /**
     * power；unit：kw·h,
     */
    public static final String POWER="power";

    /**
     * total electricity
     */
    public static final String TOTAL_ELECTRICITY="total_electricity";

    /**
     * remaining electricity
     */
    public static final String REMAINING_ELECTRICITY="remaining_electricity";

    /**
     * purchase times
     */
    public static final String PURCHASE_TIMES="purchase_times";

    /**
     * status
     */
    public static final String STATUS="status";
}
