package com.jt808.decode.utils;

import com.jt808.decode.model.CommonReplyParam;
import com.jt808.decode.model.Jt808Message;
import io.netty.buffer.ByteBuf;
import lombok.extern.slf4j.Slf4j;

/**
 * Terminal general response
 * @author HyoJung
 * @date 20230303
 */
@Slf4j
public class Message0001Parser {
    /**
     * 解析设备通用应答
     * @param msg
     * @param msgBody
     * @return
     */
    public static CommonReplyParam parse(Jt808Message msg, ByteBuf msgBody){
        //Response serial number
        int replyMsgFlowId = msgBody.readUnsignedShort();
        //Response message ID
        int replyMsgId = msgBody.readUnsignedShort();
        //Results (0: success; 1: failure; 2: message error; 3: not supported)
        int result = msgBody.readByte();
        //Encapsulated into a generic response entity class
        CommonReplyParam replyParam = new CommonReplyParam();
        replyParam.setTerminalNum(msg.getPhoneNumber());
        replyParam.setHexMsgId(NumberUtil.formatMessageId(msg.getMsgId()));
        replyParam.setMsgFlowId(msg.getMsgFlowId());
        replyParam.setReplyMessageId(NumberUtil.formatMessageId(replyMsgId));
        replyParam.setResult(result);
        replyParam.setReplyMsgFlowId(replyMsgFlowId);
        return replyParam;
    }
}
