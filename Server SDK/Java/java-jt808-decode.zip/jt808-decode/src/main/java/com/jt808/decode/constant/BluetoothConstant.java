package com.jt808.decode.constant;

/**
 * 蓝牙信息集合
 * @author HyoJung
 * @date 2022-09-21
 */
public class BluetoothConstant {
    private BluetoothConstant() {
    }
    public static final String MAC="mac";
    public static final String RSSI="rssi";
    public static final String NAME="name";
    public static final String FWVER="fwVer";
    public static final String VOLTAGE="voltage";
    public static final String TEMPERATURE="temperature";
    public static final String HUMIDITY="humidity";
    public static final String SENSOR="sensor";
}
