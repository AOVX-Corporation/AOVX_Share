package com.jt808.decode.constant;

import java.io.Serializable;

/**
 * <p>Description: Basic Enumeration</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2017/9/15
 */
public interface BaseEnum<T> extends Serializable {
    T getValue();
}
