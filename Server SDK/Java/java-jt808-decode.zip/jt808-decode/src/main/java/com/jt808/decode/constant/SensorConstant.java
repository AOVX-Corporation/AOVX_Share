package com.jt808.decode.constant;

/**
 * Sensor information
 * @author HyoJung
 * @date 2022-09-21
 */
public class SensorConstant {
    private SensorConstant() {
    }
    public static final String DATA_TYPE="data_type";
    public static final String LIGHT="light";
    public static final String TEMPERATURE="temperature";
    public static final String HUMIDITY="humidity";
    public static final String ACCELEROMETER="accelerometer";
    /**
     * High temperature threshold
     */
    public static final String TEMP_MAX="temp_max";
    /**
     * Low temperature threshold
     */
    public static final String TEMP_MIN="temp_min";
    /**
     * High humidity threshold
     */
    public static final String HUM_MAX="hum_max";
    /**
     * Low humidity threshold
     */
    public static final String HUM_MIN="hum_min";
    /**
     * Illumination threshold
     */
    public static final String LIGHT_LIMIT="light_Limit";
    /**
     * Pressure Unit:Pa
     */
    public static final String PRESSURE="pressure";
}
