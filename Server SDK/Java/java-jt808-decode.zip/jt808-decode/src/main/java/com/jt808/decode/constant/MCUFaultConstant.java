package com.jt808.decode.constant;

/**
 * MCU Fault status
 * @author Lenny
 * @date 20221226
 */
public class MCUFaultConstant {
    public static final String OVERCURRENT="Overcurrent";
    public static final String HALL="Hall";
    public static final String CONTROLLER="Controller";
    public static final String ELE_REGULATE_HIGH_TEMP="Ele_Regulate_High_Temp";
    public static final String MOTOR_HIGH_TEMP="Motor_High_Temp";
    public static final String DISCONNECTION="Disconnection";
}
