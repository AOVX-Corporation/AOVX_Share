package com.jt808.decode.model;

import lombok.Data;

/**
 * Terminal general response
 * @author HyoJung
 * @date 20230303
 */
@Data
public class CommonReplyParam {
    private String terminalNum;
    private String hexMsgId;
    private int msgFlowId;
    private int replyMsgFlowId;
    private String replyMessageId;
    private int result;
}
