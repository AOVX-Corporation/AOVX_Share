package com.jt808.decode.model;

import io.netty.buffer.ByteBuf;
import lombok.Data;

/**
 * Jt808基础消息类
 * @author Lenny
 * @date 20230302
 */
@Data
public class Jt808Message {
    /**
     * Message ID
     */
    private int msgId;

    /**
     * Terminal mobile number
     */
    private String phoneNumber;

    /**
     * Terminal mobile number array
     */
    private byte[] phoneNumberArr;

    /**
     * protocol version number
     */
    private int protocolVersion;

    /**
     * Message serial number
     */
    private int msgFlowId;

    /**
     * Whether the data is packet
     */
    private boolean multiPacket;

    /**
     * version flag
     */
    private int versionFlag;

    /**
     * Encryption method, 0: no encryption, 1: RSA encryption
     */
    private int encryptType;

    /**
     * Total message packages
     */
    private int packetTotalCount;

    /**
     * Package No
     */
    private int packetOrder;
    /**
     * Message body
     */
    private ByteBuf msgBody;
}
