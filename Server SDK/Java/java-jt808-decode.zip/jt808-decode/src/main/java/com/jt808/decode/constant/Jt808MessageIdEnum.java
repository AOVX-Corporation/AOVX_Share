package com.jt808.decode.constant;

import lombok.Getter;

/**
 * <p>Description: JT808 Message ID Enumeration</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2018/2/3
 */
@Getter
public enum Jt808MessageIdEnum {

    /**
     * Platform general response
     */
    MSG_8001(0x8001, "Platform general response"),

    /**
     * 补传分包请求
     */
    MSG_8003(0x8003, "补传分包请求"),

    /**
     * 查询服务器时间应答
     */
    MSG_8004(0x8004, "查询服务器时间应答"),

    /**
     * 终端注册应答
     */
    MSG_8100(0x8100, "终端注册应答"),

    /**
     * 文件上传完成消息应答
     */
    MSG_9212(0x9212, "文件上传完成消息应答"),

    /**
     * 报警附件上传指令
     */
    MSG_9208(0x9208, "报警附件上传指令");

    private int messageId;
    private String desc;

    Jt808MessageIdEnum(int messageId, String desc) {
        this.messageId = messageId;
        this.desc = desc;
    }
}
