package com.jt808.decode.constant;

/**
 * Device information
 * @author HyoJung
 * @date 2022-09-21
 */
public class DeviceConstant {
    private DeviceConstant() {
    }
    /**
     * work model
     * 0: Periodic mode
     * 1: Trigger mode
     * 2: Tracking mode+Trigger mode
     * 3: Clock mode+Trigger mode
     * 4: Periodic mode+Trigger mode
     */
    public static final String WORK_MODEL="work_model";
    public static final String IMEI="imei";
    public static final String ICCID="iccid";
    public static final String DEVICE_TYPE="device_type";
}
