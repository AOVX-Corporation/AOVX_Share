package com.jt808.decode;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class TestDataParser {

    private DataParser dataParser;

    @Before//执行任何方法之前都要调用初始化方法
    public void init(){
        System.out.println("---------Before---------");
        dataParser = new DataParser();
    }

    @Test
    public void receiveData() throws Exception {
        String rowData="7e0200008a000080000010002c0000000080000010000000000000000000000000000023072503132930010f310100f04e01cc000000e3ca500000185d9101cc00000cf336520000185d8f01cc00000cf323500000185d8e01cc000000e4fb5e0000185d9c01cc000000e4fb5f0000185d9801cc000000edce5f0000185d90f60e000f01deff26020e00000000fc20f70600000fdd015d657e";
        String parseDataJson=dataParser.receiveData(rowData);
        System.out.println("ParseData:"+parseDataJson);
    }

    @Test
    public void splitData() throws Exception {
        String rowData="7E020000CA593054482897004800000000B0080010000000000000000000000000000023030110180430019E310100F00E0136019A04C14B10000083039F03F22C414F56585F414D3330302D474C5F48322E305F424739354D334C415230324130345F56322E302E343A763135F423542160033C41C354216000E04DC33CB74B797D02B8C0F4C114700274BD3EB74B797D02BEBBF60A00090000000000000000F70400000DE3F81D04086459305448289789320420000012218671414D3330302D474C0000F912000F000000000000000000000000000000008C7E";

        List<String> splitDataList=dataParser.splitData(rowData);
        System.out.println("SplitData:"+splitDataList);
    }


    @After
    public void after(){
        //将被测试对象进行还原
        System.out.println("-----------After---------");
        dataParser = null;
    }
}
