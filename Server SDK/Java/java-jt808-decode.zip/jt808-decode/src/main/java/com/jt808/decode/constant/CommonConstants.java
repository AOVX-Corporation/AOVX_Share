package com.jt808.decode.constant;

public class CommonConstants {
}
