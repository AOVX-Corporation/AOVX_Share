package com.jt808.decode.constant;

/**
 * Status bit information
 * @author lenny
 */
public class Jt808StatusConstant {
    private Jt808StatusConstant() {
    }
    /**
     * 0: Operation status; 1: Shutdown status
     */
    public static final String OPERATE = "operate";
    /**
     * 0: The longitude and latitude are not encrypted by the confidential plug-in; 1: Longitude and latitude have been encrypted by confidential plug-in
     */
    public static final String CONFIDENTIAL ="confidential";
    /**
     * 0: Empty; 1: Half load; 2: Reserved; 3: Full load
     */
    public static final String LOAD ="load";
    /**
     * 0: The vehicle oil circuit is normal; 1: Vehicle oil circuit is disconnected
     */
    public static final String OIL_CIRCUIT ="oil_circuit";
    /**
     * 0: The vehicle circuit is normal; 1: Vehicle circuit disconnected
     */
    public static final String OIL_ELECTRIC ="oil_electric";
    /**
     * 0: Door unlocking; 1: Door locking
     */
    public static final String DOOR_LOCK ="door_lock";
    /**
     * 0: Normal data; 1: TOW data
     */
    public static final String NORMAL_DATA ="normal_data";
    /**
     * 0: Real time data; 1: Blind area data
     */
    public static final String REALTIME_DATA ="realtime_data";
    public static final String POWERED = "powered";
    public static final String AWAKEN="awaken";
}
