package com.jt808.decode.utils;

import com.jt808.decode.model.Heartbeat;
import com.jt808.decode.model.Jt808Message;

/**
 * 解析心跳数据
 * @author HyoJung
 * @date 20230303
 */
public class Message0002Parser {
    /**
     * 解析心跳数据
     * @param msg
     * @return
     */
    public static Heartbeat parse(Jt808Message msg){
        Heartbeat heartbeat=new Heartbeat();
        heartbeat.setTerminalNum(msg.getPhoneNumber());
        heartbeat.setHexMsgId(NumberUtil.formatMessageId(msg.getMsgId()));
        heartbeat.setMsgFlowId(msg.getMsgFlowId());
        return heartbeat;
    }
}
