package com.jt808.decode.utils;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>Description: JT808 parameter tool</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2019-03-03
 */
public class Jt808ParamUtil {

    private Jt808ParamUtil() {
    }

    private static final Map<Integer, Class<?>> PARAM_TYPE_MAP = new HashMap<>();

    static {
        PARAM_TYPE_MAP.put(0x0001, Integer.class);
        PARAM_TYPE_MAP.put(0x0010, String.class);
        PARAM_TYPE_MAP.put(0x0011, String.class);
        PARAM_TYPE_MAP.put(0x0012, String.class);
        PARAM_TYPE_MAP.put(0x0013, String.class);
        PARAM_TYPE_MAP.put(0x0017, String.class);
        PARAM_TYPE_MAP.put(0x0018, Integer.class);
        PARAM_TYPE_MAP.put(0x0027, Integer.class);
        PARAM_TYPE_MAP.put(0x0029, Integer.class);
        PARAM_TYPE_MAP.put(0x0030, Integer.class);
        PARAM_TYPE_MAP.put(0x0055, Integer.class);
        PARAM_TYPE_MAP.put(0x0056, Integer.class);
        PARAM_TYPE_MAP.put(0x0080, Integer.class);
        PARAM_TYPE_MAP.put(0xF000, String.class);
        PARAM_TYPE_MAP.put(0xF001, Short.class);
        PARAM_TYPE_MAP.put(0xF002, Short.class);
        PARAM_TYPE_MAP.put(0xF003, Short.class);
        PARAM_TYPE_MAP.put(0xF004, String.class);
        PARAM_TYPE_MAP.put(0xF005, Integer.class);
        PARAM_TYPE_MAP.put(0xF006, Byte.class);
        PARAM_TYPE_MAP.put(0xF007, Byte.class);
        PARAM_TYPE_MAP.put(0xF009, Byte.class);
        PARAM_TYPE_MAP.put(0xF00A, Byte.class);
        PARAM_TYPE_MAP.put(0xF00B, Byte.class);
        PARAM_TYPE_MAP.put(0xF00C, Byte.class);
        PARAM_TYPE_MAP.put(0xF00D, Byte.class);
        PARAM_TYPE_MAP.put(0xF00E, Short.class);
        PARAM_TYPE_MAP.put(0xF00F, Byte.class);
        PARAM_TYPE_MAP.put(0xF010, Byte.class);
        PARAM_TYPE_MAP.put(0xF011, Byte.class);
        PARAM_TYPE_MAP.put(0xF012, Byte.class);
        PARAM_TYPE_MAP.put(0xF013, Short.class);
        PARAM_TYPE_MAP.put(0xF014, Byte.class);
        PARAM_TYPE_MAP.put(0xF015, Short.class);
        PARAM_TYPE_MAP.put(0xF016, Short.class);
        PARAM_TYPE_MAP.put(0xF017, Byte.class);
        PARAM_TYPE_MAP.put(0xF018, Integer.class);
        PARAM_TYPE_MAP.put(0xF019, Byte.class);
        PARAM_TYPE_MAP.put(0xF01A, Byte.class);
        PARAM_TYPE_MAP.put(0xF01B, Byte.class);
        PARAM_TYPE_MAP.put(0xF01C, Short.class);
        PARAM_TYPE_MAP.put(0xF01D, Integer.class);
        PARAM_TYPE_MAP.put(0xF01E, Integer.class);
        PARAM_TYPE_MAP.put(0xF01F, Byte.class);
        PARAM_TYPE_MAP.put(0xF020, Byte.class);
        PARAM_TYPE_MAP.put(0xF021, Short.class);
        PARAM_TYPE_MAP.put(0xF022, Integer.class);
        PARAM_TYPE_MAP.put(0xF023, Byte.class);
        PARAM_TYPE_MAP.put(0xF024, Short.class);
        PARAM_TYPE_MAP.put(0xF025, Short.class);
        PARAM_TYPE_MAP.put(0xF026, Short.class);
        PARAM_TYPE_MAP.put(0xF027, Short.class);
        PARAM_TYPE_MAP.put(0xF028, Integer.class);
        PARAM_TYPE_MAP.put(0xF029, Byte.class);
        PARAM_TYPE_MAP.put(0xF02A, Byte.class);
        PARAM_TYPE_MAP.put(0xF02B, Integer.class);
        PARAM_TYPE_MAP.put(0xF02C, Byte.class);
        PARAM_TYPE_MAP.put(0xF02D, Byte.class);
        PARAM_TYPE_MAP.put(0xF02E, Integer.class);
        PARAM_TYPE_MAP.put(0xF02F, Integer.class);
        PARAM_TYPE_MAP.put(0xF030, String.class);
    }

    /**
     * Obtain the type of JT808 terminal parameters
     *
     * @param paramId Parameter ID
     * @return Parameter Type
     */
    public static Class<?> getParamType(int paramId) {
        return PARAM_TYPE_MAP.get(paramId);
    }
}

