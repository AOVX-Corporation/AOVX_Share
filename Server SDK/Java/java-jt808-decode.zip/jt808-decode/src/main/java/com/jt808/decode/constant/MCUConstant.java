package com.jt808.decode.constant;

/**
 * MCU
 * @author Lenny
 * @date 20221206
 */
public class MCUConstant {
    public static final String MCU_MODEL_STATUS="MCU_Model_Status";
    public static final String MCU_FAULT_STATUS="MCU_Fault_Status";
    public static final String MCU_VOLTAGE="MCU_Voltage";
    public static final String MCU_SPEED="MCU_Speed";
    public static final String MCU_ODO="MCU_ODO";
    public static final String MCU_SOC="MCU_SOC";
    public static final String BATTERY_CAPACITY="Battery_Capacity";
    public static final String REMAIN_BATTERY_CAPACITY="Remain_Battery_Capacity";
    public static final String BATTERY_DISCHARGE_CNT="Battery_Discharge_CNT";
}
