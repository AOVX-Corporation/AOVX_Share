package com.jt808.decode.constant;

/**
 * MUC Model status
 * @author Lenny
 * @date 20221226
 */
public class MCUModelConstant {
    public static final String MCU_SPEED_LIMIT="MCU_Speed_Limit";
    public static final String BATTERY_LOCK="Battery_Lock";
    public static final String ANTI_THEFT="Anti_Theft";
}
