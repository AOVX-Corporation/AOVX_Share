package com.jt808.decode.utils;

import com.jt808.decode.model.Jt808Message;
import com.jt808.decode.model.TerminalRegisterInfo;
import io.netty.buffer.ByteBuf;

/**
 * Terminal registration
 * @author HyoJung
 * @date 20230303
 */
public class Message0100Parser {

    /**
     * Terminal registration
     * @param msg
     * @param msgBody
     * @return
     */
    public static TerminalRegisterInfo parse(Jt808Message msg, ByteBuf msgBody){
        TerminalRegisterInfo terminalRegisterInfo;
        if (msg.getVersionFlag() == 1) {
            //Check message body length
            terminalRegisterInfo = parseTerminalRegisterInfo2019(msgBody);
        } else {
            //Check message body length
            terminalRegisterInfo = parseTerminalRegisterInfo(msgBody);
        }
        terminalRegisterInfo.setTerminalNum(msg.getPhoneNumber());
        terminalRegisterInfo.setHexMsgId(NumberUtil.formatMessageId(msg.getMsgId()));
        terminalRegisterInfo.setMsgFlowId(msg.getMsgFlowId());
        //Terminal registration response
        String authCode = msg.getPhoneNumber();
        terminalRegisterInfo.setAuthCode(authCode);
        return terminalRegisterInfo;
    }

    /**
     * Decode the terminal registration information of JT808-2011 and JT808-2013 versions
     *
     * @param msgBodyBuf
     * @return
     */
    private static TerminalRegisterInfo parseTerminalRegisterInfo(ByteBuf msgBodyBuf) {
        TerminalRegisterInfo registerInfo = new TerminalRegisterInfo();
        //Province Id
        registerInfo.setProvinceId(msgBodyBuf.readShort());
        //City Id
        registerInfo.setCityId(msgBodyBuf.readShort());
        //Producer Id
        registerInfo.setProducerId(CommonUtil.readGbkString(msgBodyBuf, 5));
        try {
            //Terminal type
            registerInfo.setTerminalModelType(CommonUtil.readGbkString(msgBodyBuf, 20));
            //terminal number
            registerInfo.setTerminalCode(CommonUtil.readGbkString(msgBodyBuf, 7));
            //Vehicle plate color
            registerInfo.setVehiclePlateColor(msgBodyBuf.readByte());
            //Vehicle plate number
            registerInfo.setVehicleNo(CommonUtil.readGbkString(msgBodyBuf, msgBodyBuf.readableBytes()));
        } catch (Exception e) {
            //JT808-2011 the terminal model before the revision is 8 bytes
            msgBodyBuf.readerIndex(9);
            //Terminal type
            registerInfo.setTerminalModelType(CommonUtil.readGbkString(msgBodyBuf, 8));
            //terminal number
            registerInfo.setTerminalCode(CommonUtil.readGbkString(msgBodyBuf, 7));
            //Vehicle plate color
            registerInfo.setVehiclePlateColor(msgBodyBuf.readByte());
            //Vehicle plate number
            registerInfo.setVehicleNo(CommonUtil.readGbkString(msgBodyBuf, msgBodyBuf.readableBytes()));
        }

        return registerInfo;
    }

    /**
     * Decode the terminal registration information of JT808-2019
     *
     * @param msgBodyBuf
     * @return
     */
    private static TerminalRegisterInfo parseTerminalRegisterInfo2019(ByteBuf msgBodyBuf) {
        TerminalRegisterInfo registerInfo = new TerminalRegisterInfo();
        //Province Id
        registerInfo.setProvinceId(msgBodyBuf.readShort());
        //city id
        registerInfo.setCityId(msgBodyBuf.readShort());
        //Producer Id
        registerInfo.setProducerId(CommonUtil.readGbkString(msgBodyBuf, 11));
        //terminal type
        registerInfo.setTerminalModelType(CommonUtil.readGbkString(msgBodyBuf, 30));
        //terminal number
        registerInfo.setTerminalCode(CommonUtil.readGbkString(msgBodyBuf, 30));
        //Vehicle plate color
        registerInfo.setVehiclePlateColor(msgBodyBuf.readByte());
        //Vehicle plate number
        registerInfo.setVehicleNo(CommonUtil.readGbkString(msgBodyBuf, msgBodyBuf.readableBytes()));
        return registerInfo;
    }
}
