package com.jt808.decode.model;

import lombok.Data;

/**
 * <p>Description: JT808 terminal registration information</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2018/9/15
 */
@Data
public class TerminalRegisterInfo {
    private String terminalNum;
    private String hexMsgId;
    private int msgFlowId;
    /**
     * province Id
     */
    private int provinceId;

    /**
     * city Id
     */
    private int cityId;

    /**
     * producer Id
     */
    private String producerId;

    /**
     * terminal Model Type
     */
    private String terminalModelType;

    /**
     * terminal id
     */
    private String terminalCode;

    /**
     * vehicle Plate Color
     */
    private int vehiclePlateColor;

    /**
     * vehicle No
     */
    private String vehicleNo;

    /**
     * Authentication code
     */
    private String authCode;

    /**
     * Terminal IMEI
     */
    private String imeiCode;

    /**
     * Software version number
     */
    private String softwareVersion;
    private String replyMsg;
}
