package com.jt808.decode.constant;

import lombok.Getter;

/**
 * <p>Description: JT808 reply result enumeration</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2017/9/15
 */
@Getter
public enum Jt808ReplyResultEnum {
    /**
     * success
     */
    SUCCESS(0, "success"),

    /**
     * failed
     */
    FAILED(1, "failed"),

    /**
     * message error
     */
    MSG_ERROR(2, "message error"),

    /**
     * not support
     */
    NOT_SUPPORT(3, "not support"),

    /**
     * Alarm processing confirmation
     */
    ALARM_PROCESSING_CONFIRM(4, "Alarm processing confirmation");

    private int value;
    private String desc;

    Jt808ReplyResultEnum(int value, String desc) {
        this.value = value;
        this.desc = desc;
    }

}
