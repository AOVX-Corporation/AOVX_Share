package com.jt808.decode.model;

import lombok.Data;

/**
 * <p>Description: JT808 terminal authentication information</p>
 *
 * @author lenny
 * @version 1.0.1
 * @date 2018/9/15
 */
@Data
public class TerminalAuthInfo {
    private String terminalNum;
    private String hexMsgId;
    private int msgFlowId;
    /**
     * Authentication code
     */
    private String authCode;

    /**
     * Terminal IMEI
     */
    private String imeiCode;

    /**
     * Software version number
     */
    private String softwareVersion;
    private String replyMsg;
}
