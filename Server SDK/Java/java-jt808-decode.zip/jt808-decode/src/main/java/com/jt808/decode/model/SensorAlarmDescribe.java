package com.jt808.decode.model;

import lombok.Data;

/**
 * Sensor Alarm Description
 * @author HyoJung
 * @date 20221208
 */
@Data
public class SensorAlarmDescribe {
    /**
     * Alarm type
     */
    private String type;
    /**
     * Current value
     */
    private String current;
    /**
     * Threshold
     */
    private String threshold;
}
