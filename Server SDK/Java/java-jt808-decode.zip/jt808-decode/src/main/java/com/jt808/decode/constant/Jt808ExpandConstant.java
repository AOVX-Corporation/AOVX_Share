package com.jt808.decode.constant;

/**
 * 808 expand information Map,Key
 * @author HyoJung
 * @date 2022-9-21
 */
public class Jt808ExpandConstant {
    private Jt808ExpandConstant() {
    }
    /**
     * Oil level value, liters, if there are multiple oil levels, use ";" separate
     */
    public static final String FUEL = "fuel";
    /**
     * Speed acquired by tachograph
     */
    public static final String RECODER_SPEED = "recoder_speed";
    /**
     * Events requiring manual response
     */
    public static final String RESPONSE_EVENT = "response_event";
    /**
     * Tyre pressure, unit: pa; Use ";" separate
     */
    public static final String TYRE = "tyre";
    /**
     *Temperature in the compartment
     */
    public static final String CARRIAGE_TEMPERATURE = "carriage_temperature";
    /**
     * Description of over speed alarm
     */
    public static final String SPEED_ALARM_DESCRIBE="speed_alarm_describe";
    /**
     * Entry/exit area/route alarm description
     */
    public static final String GIS_ALARM_DESCRIBE="gis_alarm_describe";
    /**
     * Signal status bit
     */
    public static final String SIGNAL_STATUS="signal_status";
    /**
     * IO Status bit
     */
    public static final String IO_STATUS="io_status";
    /**
     * Analog quantity
     */
    public static final String ANALOG_QUANTITY="analog_quantity";
    /**
     * external voltage
     */
    public static final String EXTERNAL_VOLTAGE="external_voltage";
    /**
     * 固件版本
     */
    public static final String SOFTWARE_VERSION="software_version";
    /**
     * bluetooth information
     */
    public static final String BLUETOOTH="bluetooth";
    /**
     * WIFI information
     */
    public static final String WIFI="wifi";
    /**
     * GPIO Status
     */
    public static final String GPIO="GPIO";
    /**
     * sensor information
     */
    public static final String SENSOR="sensor";
    /**
     * device information
     */
    public static final String DEVICE="device";
    /**
     * illumination alarm describe
     */
    public static final String LIGHT_ALARM_DESCRIBE="light_alarm_describe";
    /**
     * temperature alarm describe
     */
    public static final String TEMP_ALARM_DESCRIBE="temp_alarm_describe";
    /**
     * meter data information
     */
    public static final String METER="meter";
    /**
     * charge status
     */
    public static final String BATTERY_CHARGE="battery_charge";
    /**
     * auxiliary information
     */
    public static final String AUXILIARY="auxiliary";

}
